import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Lightbulb } from "lucide-react"

/**
 * Props for the AiInsightsCard component.
 * @typedef {object} AiInsightsCardProps
 * @property {string} title - The title of the insights card.
 * @property {string[]} insights - An array of strings, each representing an AI-generated insight.
 */
interface AiInsightsCardProps {
  title: string
  insights: string[]
}

/**
 * AiInsightsCard Component
 *
 * Displays a card with AI-generated insights.
 *
 * @param {AiInsightsCardProps} props - The props for the component.
 * @returns {JSX.Element} A card displaying AI insights.
 */
export function AiInsightsCard({ title, insights }: AiInsightsCardProps) {
  return (
    <Card className="border-l-4 border-[#FF6B35] shadow-md">
      <CardHeader className="flex flex-row items-center space-x-2 pb-2">
        <Lightbulb className="h-5 w-5 text-[#FF6B35]" />
        <CardTitle className="text-lg font-semibold text-gray-800">{title}</CardTitle>
      </CardHeader>
      <CardContent className="pt-2">
        <ul className="list-disc pl-5 space-y-1 text-sm text-gray-700">
          {insights.map((insight, index) => (
            <li key={index}>{insight}</li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}
