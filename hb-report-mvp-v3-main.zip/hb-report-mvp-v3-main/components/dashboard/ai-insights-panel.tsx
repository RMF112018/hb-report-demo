"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import type { AIInsight } from "@/types/dashboard"
import { Sparkles, TrendingUp, AlertTriangle, Lightbulb, Target, RefreshCw, X } from "lucide-react"

interface AIInsightsPanelProps {
  insights: AIInsight[]
  onRefresh: () => void
}

export function AIInsightsPanel({ insights, onRefresh }: AIInsightsPanelProps) {
  const getInsightIcon = (type: string) => {
    switch (type) {
      case "trend":
        return <TrendingUp className="h-4 w-4" />
      case "alert":
        return <AlertTriangle className="h-4 w-4" />
      case "recommendation":
        return <Lightbulb className="h-4 w-4" />
      case "prediction":
        return <Target className="h-4 w-4" />
      default:
        return <Sparkles className="h-4 w-4" />
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "destructive"
      case "medium":
        return "default"
      case "low":
        return "secondary"
      default:
        return "outline"
    }
  }

  const highPriorityInsights = insights.filter((i) => i.severity === "high" && !i.dismissed)
  const otherInsights = insights.filter((i) => i.severity !== "high" && !i.dismissed)

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-blue-500" />
            AI Insights
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onRefresh}>
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <ScrollArea className="h-[calc(100vh-200px)]">
          <div className="space-y-4">
            {/* High Priority Insights */}
            {highPriorityInsights.length > 0 && (
              <div>
                <h4 className="text-sm font-medium text-red-600 mb-2">Urgent Attention</h4>
                <div className="space-y-3">
                  {highPriorityInsights.map((insight) => (
                    <InsightCard key={insight.id} insight={insight} />
                  ))}
                </div>
              </div>
            )}

            {/* Other Insights */}
            {otherInsights.length > 0 && (
              <div>
                {highPriorityInsights.length > 0 && (
                  <h4 className="text-sm font-medium text-gray-600 mb-2 mt-6">Additional Insights</h4>
                )}
                <div className="space-y-3">
                  {otherInsights.map((insight) => (
                    <InsightCard key={insight.id} insight={insight} />
                  ))}
                </div>
              </div>
            )}

            {insights.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Sparkles className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No insights available</p>
                <p className="text-xs mt-1">Add cards to your dashboard to generate insights</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}

function InsightCard({ insight }: { insight: AIInsight }) {
  const getInsightIcon = (type: string) => {
    switch (type) {
      case "trend":
        return <TrendingUp className="h-4 w-4" />
      case "alert":
        return <AlertTriangle className="h-4 w-4" />
      case "recommendation":
        return <Lightbulb className="h-4 w-4" />
      case "prediction":
        return <Target className="h-4 w-4" />
      default:
        return <Sparkles className="h-4 w-4" />
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "destructive"
      case "medium":
        return "default"
      case "low":
        return "secondary"
      default:
        return "outline"
    }
  }

  return (
    <div
      className={`p-3 rounded-lg border ${
        insight.severity === "high"
          ? "border-red-200 bg-red-50"
          : insight.severity === "medium"
            ? "border-blue-200 bg-blue-50"
            : "border-gray-200 bg-gray-50"
      }`}
    >
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center gap-2">
          {getInsightIcon(insight.type)}
          <span className="text-sm font-medium">{insight.title}</span>
        </div>
        <Badge variant={getSeverityColor(insight.severity) as any} className="text-xs">
          {insight.severity}
        </Badge>
      </div>

      <p className="text-xs text-gray-600 mb-2">{insight.description}</p>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-500">{Math.round(insight.confidence * 100)}% confidence</span>
          {insight.actionable && (
            <Badge variant="outline" className="text-xs">
              Actionable
            </Badge>
          )}
        </div>
        <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
          <X className="h-3 w-3" />
        </Button>
      </div>
    </div>
  )
}
