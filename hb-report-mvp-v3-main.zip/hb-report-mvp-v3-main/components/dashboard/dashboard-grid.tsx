"use client"

import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd"
import { DashboardCard } from "./dashboard-card"
import type { DashboardCard as DashboardCardType } from "@/types/dashboard"

interface DashboardGridProps {
  cards: DashboardCardType[]
  editMode: boolean
  onCardUpdate: (cardId: string, updates: any) => void
  onCardRemove: (cardId: string) => void
  selectedCard: string | null
  onCardSelect: (cardId: string | null) => void
}

export function DashboardGrid({
  cards,
  editMode,
  onCardUpdate,
  onCardRemove,
  selectedCard,
  onCardSelect,
}: DashboardGridProps) {
  const visibleCards = cards.filter((card) => card.visible)

  const handleDragEnd = (result: any) => {
    if (!result.destination || !editMode) return

    const sourceIndex = result.source.index
    const destinationIndex = result.destination.index

    if (sourceIndex === destinationIndex) return

    // Update card positions based on drag result
    const updatedCards = Array.from(visibleCards)
    const [reorderedCard] = updatedCards.splice(sourceIndex, 1)
    updatedCards.splice(destinationIndex, 0, reorderedCard)

    // Update positions
    updatedCards.forEach((card, index) => {
      const row = Math.floor(index / 6) // More cards per row
      const col = index % 6
      onCardUpdate(card.id, { position: { x: col, y: row } })
    })
  }

  const getGridCols = (size: string) => {
    switch (size) {
      case "small":
        return "col-span-1"
      case "medium":
        return "col-span-2"
      case "large":
        return "col-span-3"
      case "xl":
        return "col-span-4"
      default:
        return "col-span-2"
    }
  }

  const getGridRows = (size: string) => {
    switch (size) {
      case "small":
        return "row-span-1"
      case "medium":
        return "row-span-1" // Reduced height for more compact layout
      case "large":
        return "row-span-2"
      case "xl":
        return "row-span-2" // Reduced height
      default:
        return "row-span-1"
    }
  }

  if (editMode) {
    return (
      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="dashboard-grid">
          {(provided) => (
            <div
              {...provided.droppableProps}
              ref={provided.innerRef}
              className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-8 gap-2 auto-rows-fr"
            >
              {visibleCards.map((card, index) => (
                <Draggable key={card.id} draggableId={card.id} index={index}>
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                      className={`${getGridCols(card.size)} ${getGridRows(card.size)} ${
                        snapshot.isDragging ? "opacity-75 rotate-1 scale-105" : ""
                      } transition-all duration-200`}
                    >
                      <DashboardCard card={card} />
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    )
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-8 gap-2 auto-rows-fr">
      {visibleCards.map((card) => (
        <div key={card.id} className={`${getGridCols(card.size)} ${getGridRows(card.size)}`}>
          <DashboardCard card={card} />
        </div>
      ))}
    </div>
  )
}
