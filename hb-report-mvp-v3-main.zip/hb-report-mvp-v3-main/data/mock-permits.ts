import type { Permit } from "@/types"
import mockPermitsData from "./mock-permits.json"

export const mockPermits: Permit[] = mockPermitsData as Permit[]
